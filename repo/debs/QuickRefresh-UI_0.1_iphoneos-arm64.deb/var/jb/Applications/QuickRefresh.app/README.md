##  QuickRefresh UI

UI for my jailbroken tool for quickly run restart actions such as Respring or Userspace Reboot
