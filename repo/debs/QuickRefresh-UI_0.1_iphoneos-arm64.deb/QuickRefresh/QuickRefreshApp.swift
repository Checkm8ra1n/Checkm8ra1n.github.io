//
//  QuickRefreshApp.swift
//  QuickRefresh
//
//  Created by Checkm8ra1n on 13/02/26.
//

import SwiftUI

@main
struct QuickRefreshApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
