//
//  ContentView.swift
//  QuickRefresh
//
//  Created by Checkm8ra1n on 13/02/26.
//

import SwiftUI
import Darwin

@_silgen_name("notify_post")
func notify_post(_ name: UnsafePointer<CChar>) -> Int32

func notify_post(_ name: String) {
    name.withCString { cString in
        _ = notify_post(cString)
    }
}

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Spacer()
                
                Button {
                    notify_post("net.checkm8ra1n.quickrefresh.respring")
                } label: {
                    Label("Respring", systemImage: "arrow.clockwise.circle")
                }
                .buttonStyle(.blue)
                
                Button {
                    notify_post("net.checkm8ra1n.quickrefresh.userspaceReboot")
                } label: {
                    Label("Userspace Reboot", systemImage: "repeat.circle")
                }
                .buttonStyle(.orange)
                Button {
                    notify_post("net.checkm8ra1n.quickrefresh.restart")
                } label: {
                    HStack(spacing: 10) {           // spacing tra icona e testo
                        Image(systemName: "triangle.circle")
                            .rotationEffect(.degrees(-90)) // ruota l'icona
                        Text("Restart")
                    }
                }
                .buttonStyle(.green)


                
                Button {
                    notify_post("net.checkm8ra1n.quickrefresh.shutdown")
                } label: {
                    Label("Shutdown", systemImage: "power.circle.fill")
                }
                .buttonStyle(.red)
                
                Spacer()
            }
            .padding()
            .navigationTitle("QuickRefresh")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarHidden(false)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

// Extension per stile bottoni
extension Button {
    func buttonStyle(_ color: Color) -> some View {
        self
            .padding()
            .frame(maxWidth: .infinity)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(12)
    }
}


#Preview {
    ContentView()
}
